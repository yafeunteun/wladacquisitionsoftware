package avis;

import exception.BadEntry;


public class Film extends Item {

	/** 
	 * @uml.property name="realisateur"
	 */
	private String realisateur;

	/** 
	 * @uml.property name="scenariste"
	 */
	private String scenariste;

	/** 
	 * @uml.property name="duree"
	 */
	private int duree;

	
	/**
	 * 
	 * @param pseudo
	 * @param password
	 * @param titre
	 * @param genre
	 * @param realisateur
	 * @param scenariste
	 * @param duree
	 */
	public Film(String titre, String genre, String realisateur, String scenariste, int duree) throws BadEntry{
		super(titre,genre);
		//tests sur le realisateur, le scenariste et la duree
		if ((realisateur == null) || (scenariste == null))
			throw new BadEntry("le scenariste ou le realisateur ne sont pas instancies");
		if(duree <= 0)
			throw new BadEntry("la duree du film est inferieur a 0"); 
		
		this.realisateur = realisateur;
		this.scenariste = scenariste;
		this.duree = duree;		
	}

		
	/**
	 * méthode toString
	 * @return titre, genre, realisateur, scenariste, duree et tous les opinions du film
	 */
	public String toString() {
		String message = "Le film s'appelle : "+this.titre+". genre : "+this.genre+", realisateur : "+this.realisateur+", scenariste : "+this.scenariste+", duree : "+this.duree+", note moyenne : "+this.calculMoyenne();
		for(Opinion opinion : mesOpinions) {
			message += "\n [" + opinion.toString() + "]";
		}
		
		return message;
	}
		
		
		/**
		 */
		public void main(){
		}

}

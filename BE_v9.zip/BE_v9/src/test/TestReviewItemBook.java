package test;

import avis.SocialNetwork;

import exception.BadEntry;
import exception.ItemBookAlreadyExists;
import exception.MemberAlreadyExists;
import exception.NotItem;
import exception.NotMember;


public class TestReviewItemBook {

	
	public static int reviewItemBookBadEntryTest (SocialNetwork sn, String pseudo, String pwd, String titre, float note, String commentaire, String idTest, String messErreur){
		// verifie que l'ajout d'une opinion (pseudo, pwd, profil) est refusee (levee de l'exception BadEntry et  pas de modification du sn)
		// si c'est bien le cas, ne fait rien
		// sinon, affiche le message d'erreur passe en parametre
		int nbBooks = sn.nbBooks();
		try {
			sn.reviewItemBook (pseudo, pwd, titre, note, commentaire);
			System.out.println ("Test " + idTest + " : " + messErreur);
			return 1;
		}
		catch (BadEntry e) {
			if (sn.nbBooks() != nbBooks) {
				System.out.println("Test " + idTest + " : l'exception BadEntry a bien été levée mais le nombre de livres a été modifié");
				return 1;
			}
			else 
				return 0;
		}
		catch (Exception e) {
			System.out.println ("Test " + idTest + " : exception non prévue. " + e); 
			e.printStackTrace();
			return 1;
		}
	}

	public static int reviewItemBookOKTest (SocialNetwork sn, String pseudo, String pwd, String titre, float note, String commentaire, String idTest){
		//retourne 1 pour une opinion qui n'a pas ete creee ou non modifiee
		//retourne 0 sinon
		try{
			String str = sn.toString(); // Je récupère l'état du SN 
			sn.reviewItemBook (pseudo, pwd, titre, note, commentaire);
			
			//je verifie que le SN a ete modifie, alors cela implique une modification de l'opinion
			if(!sn.toString().equals(str)) {
				return 0;
			}
			else{
				System.out.println("Le social network n'a pas ete modifie donc l'erreur n'a pas ete relevee. Test " + idTest);
				return 1;
			}
		}
		catch (Exception e) {
			System.out.println ("Test " + idTest + " : exception non prévue. " + e); 
			e.printStackTrace();
			return 1;
		}
	}

	public static int reviewItemBookNotMemberTest (SocialNetwork sn, String pseudo, String pwd, String titre, float note, String commentaire, String idTest, String messErreur){
		int nbBooks = sn.nbBooks();
		try {
			sn.reviewItemBook (pseudo, pwd, titre, note, commentaire);
			System.out.println ("Test " + idTest + " : " + messErreur);
			return 1;
		}
		catch (NotMember e) {
			if (sn.nbBooks() != nbBooks) {
				System.out.println("Test " + idTest + " : l'exception NotMember a bien été levée mais le nombre de livres a été modifié");
				return 1;
			}
			else
				return 0;
		}
		catch (Exception e) {
			System.out.println ("Test " + idTest + " : exception non prévue. " + e); 
			e.printStackTrace();
			return 1;
		}
	}
	
	public static int reviewItemBookNotItemTest (SocialNetwork sn, String pseudo, String pwd, String titre, float note, String commentaire, String idTest, String messErreur){
		int nbBooks = sn.nbBooks();
		try {
			sn.reviewItemBook (pseudo, pwd, titre, note, commentaire);
			System.out.println ("Test " + idTest + " : " + messErreur);
			return 1;
		}
		catch (NotItem e) {
			if (sn.nbBooks() != nbBooks) {
				System.out.println("Test " + idTest + " : l'exception MemberAlreadyExists a bien été levée mais le nombre de livres a été modifié");
				return 1;
			}
			else
				return 0;
		}
		catch (Exception e) {
			System.out.println ("Test " + idTest + " : exception non prévue. " + e); 
			e.printStackTrace();
			return 1;
		}
	}




	public static void main(String[] args) {

		int nbLivres = 0;

		int nbTests = 0;
		int nbErreurs = 0;
		
		System.out.println("Tests pour l'ajout d'opinions sur un livre.");


		SocialNetwork sn = new SocialNetwork();

		// tests de reviewItemBook
		nbLivres = sn.nbBooks();

		// <=> fiche numéro 5

		// tentative d'ajout de membres avec entrées "incorrectes"

		try {
			sn.addMember("BBBB","bbbb","profil de test");
			sn.addMember("Paul","paul","profil de paul");
			sn.addMember("Antoine","antoine","profil d'antoine");
			sn.addMember("Alice","alice","profil d'alice");
		}
		catch (MemberAlreadyExists e) {
			System.out.println("Il ne devrait pas y avoir de levée d'exception");
			System.exit(0);
		}
		catch (BadEntry e) {
			System.out.println("Il ne devrait pas y avoir de levée d'exception");
			System.exit(0);
		}
		
		try {
			sn.addItemBook("BBBB", "bbbb", "Germinal", "classique", "Emile Zola", 500);
			sn.addItemBook("BBBB", "bbbb", "Journal d'Anne Frank", "récit historique", "Anne Franck", 200);
			sn.addItemBook("BBBB", "bbbb", "Harry Potter", "Jeunesse", "J.K. Rowlings", 500);
			sn.addItemBook("BBBB", "bbbb", "Le rouge et le noir", "littérature", "Stendhal", 500);
		}
		catch (BadEntry e) {
			System.out.println("Il ne devrait pas y avoir de levée d'exception");
			System.exit(0);
		}
		catch (ItemBookAlreadyExists e) {
			System.out.println("Il ne devrait pas y avoir de levée d'exception");
			System.exit(0);
		}		
		catch (NotMember e) {
			System.out.println("Il ne devrait pas y avoir de levée d'exception");
			System.exit(0);
		}
		
		
		nbTests++;
		nbErreurs += reviewItemBookBadEntryTest ( sn, null, "qsdfgh", "Germinal", 4, "Ce livre est extraordinaire !", "5.1", "L'ajout d'une opinion dont le pseudo n'est pas instancié est accepté");
		nbTests++;
		nbErreurs += reviewItemBookBadEntryTest ( sn, " ", "qsdfgh", "Germinal", 4, "Ce livre est extraordinaire !", "5.2", "L'ajout d'une opinion dont le pseudo ne contient pas un caracteres, autre que des espaces, est accepté");
		nbTests++;
		nbErreurs += reviewItemBookBadEntryTest ( sn, "B", null, "Germinal", 4, "Ce livre est extraordinaire !", "5.3", "L'ajout d'une opinion dont le password n'est pas instancié est accepté");
		nbTests++;
		nbErreurs += reviewItemBookBadEntryTest ( sn, "B", "   qwd ", "Germinal", 4, "Ce livre est extraordinaire !", "5.4", "L'ajout d'une opinion dont le password ne contient pas au moins 4 caracteres, autre que des espaces de début ou de fin, est accepté");
		nbTests++;
		nbErreurs += reviewItemBookBadEntryTest ( sn, "BBBB", "bbbb", null, 4, "Ce livre est extraordinaire !", "5.5", "L'ajout d'une opinion dont le titre du livre n'est pas instancié est accepté");
		nbTests++;
		nbErreurs += reviewItemBookBadEntryTest ( sn, "BBBB", "bbbb", "    ", 4, "Ce livre est extraordinaire !", "5.6", "L'ajout d'une opinion dont le titre du livre ne contenant que des espaces est accepté");
		nbTests++;
		nbErreurs += reviewItemBookBadEntryTest ( sn, "BBBB", "bbbb", "Germinal",-3, "Ce livre est extraordinaire !", "5.7", "L'ajout d'une opinion dont la note est négative est accepté");
		nbTests++;
		nbErreurs += reviewItemBookBadEntryTest ( sn, "BBBB", "bbbb", "Germinal", 7, "Ce livre est extraordinaire !", "5.8", "L'ajout d'une opinion dont la note est supérieure à 5 est accepté");
		nbTests++;
		nbErreurs += reviewItemBookBadEntryTest ( sn, "BBBB", "bbbb", "Germinal", 4, null, "5.9", "L'ajout d'une opinion dont le commentaire n'est pas instancié est accepté");
		

		// <=> fiche numéro 6

		// ajout de 3 livres avec des paramètres d'entrées corrects

		nbTests++;
		nbErreurs += reviewItemBookOKTest (sn, "Paul", "paul", "Germinal", 4, "Ce livre est extraordinaire !", "6.1a");
		nbTests++;
		nbErreurs += reviewItemBookOKTest (sn, "Antoine", "antoine", "Harry Potter", 3.5f, "Ce livre est magique !", "6.1b");
		nbTests++;
		nbErreurs += reviewItemBookOKTest (sn, "Alice", "alice", "Journal d'Anne Frank", 5, "Ce livre est éprouvant !", "6.1c");
		//le membre Paul commente le meme livre, mais modifie son opinion
		nbTests++;
		nbErreurs += reviewItemBookOKTest (sn, "Paul", "paul", "Germinal", 1, "Je n'ai pas aimé ce livre", "6.2");
		
		// Test de l'ajout d'un avis sur un livre non existant
		nbTests++;
		nbErreurs += reviewItemBookNotItemTest (sn, "Paul", "paul", "Débuter en C++", 4, "Bonne lecture de chevet", "6.3","L'ajout d'un commentaire sur un livre non existant est accepte");
		nbTests++;
		nbErreurs += reviewItemBookNotMemberTest (sn, "Julien", "julien", "Le rouge et le noir", 5, "Ce livre est emouvant !", "6.4","L'ajout d'un commentaire alors que le pseudo et le password du membre ne correspondent pas est accepte");
		nbTests++;
		nbErreurs += reviewItemBookNotMemberTest (sn, "Alice", "wrongpassword", "Le rouge et le noir", 5, "Ce livre est emouvant !", "6.5","L'ajout d'un commentaire alors que le pseudo et le password du membre ne correspondent pas est accepte");

	

		System.out.println(sn);

		//bilan du test de addReviewBook
		System.out.println("TestsAddReviewBook :   " + nbErreurs + " erreur(s) / " +  nbTests + " tests effectués");

		// ajouts au bilan en cours si le bilan est passé en paramètre
        if ((args != null) && (args.length == 2)) {        
           nbTests = nbTests + new Integer(args[0]);
           nbErreurs = nbErreurs + new Integer(args[1]);       
           args[0] = "" + nbTests;
           args[1] = "" + nbErreurs;
        }
        
    }  // fin du main
	
	
}
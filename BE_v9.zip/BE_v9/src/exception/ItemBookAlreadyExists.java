package exception;

public class ItemBookAlreadyExists extends Exception {

}

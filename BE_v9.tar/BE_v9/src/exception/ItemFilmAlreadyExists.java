package exception;

public class ItemFilmAlreadyExists extends Exception {

}

package test;

public class Tests {

	   /**
	    * @param args
	    */
	   public static void main(String[] args) {
	      // TODO Auto-generated method stub

	      String nbTests = "" + 0;
	      String nbErreurs = "" + 0;
	      String [] resultats = new String[] {"0", "0"};
	      
	      // Tests d'initialisation
	      TestsInitialisation.main(resultats);
	      
	      System.out.println("\n\n ***************************************\n");

	      // Tests pour l'ajout de membres
	      TestsAddMember.main(resultats);
	      
	      System.out.println("\n\n ***************************************\n");

	      // Tests pour Book
	      TestAddItemBook.main(resultats);

	      System.out.println("\n\n ***************************************\n");

	      TestReviewItemBook.main(resultats);
	      
	      System.out.println("\n\n ***************************************\n");
	      
	      // Tests pour Film
	      TestAddItemFilm.main(resultats);
	      
	      System.out.println("\n\n ***************************************\n");
	      
	      TestReviewItemFilm.main(resultats);
	      
	      System.out.println("\n\n ***************************************\n");

	      // Tests pour la consultation des items
	      TestConsultItem.main(resultats);
	      
	      System.out.println("\n\n ***************************************\n");

	      
	      // Affichage bilan
	      System.out.println("Bilan des Tests :   " + resultats[1] + " erreur(s) / " +  resultats[0] + " tests effectués");
	      
	   }

	}
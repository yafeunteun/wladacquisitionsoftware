package test;

import avis.SocialNetwork;

import exception.BadEntry;
import exception.ItemFilmAlreadyExists;
import exception.MemberAlreadyExists;
import exception.NotMember;


public class TestConsultItem {
	
	
	public static int consultItemBadEntryTest (SocialNetwork sn, String pseudo, String pwd, String titre, String idTest, String messErreur){

		try {
			sn.consultItems(titre); 
			System.out.println ("Test " + idTest + " : " + messErreur);
			return 1;
		}
		catch (BadEntry e) {
			return 0;
		}
		catch (Exception e) {
			System.out.println ("Test " + idTest + " : exception non prévue. " + e); 
			e.printStackTrace();
			return 1;
		}
	}
	
	public static int consultItemOkTest (SocialNetwork sn, String pseudo, String pwd, String titre, String idTest){

		try {
			sn.consultItems(titre); 
			return 0;
		}
		catch (Exception e) {
			System.out.println ("Test " + idTest + " : exception non prévue. " + e); 
			e.printStackTrace();
			return 1;
		}
	}
	
	
	public static void main(String[] args) {
	
		System.out.println("Tests pour la consultation d'un item");
		int nbErreurs = 0;

		SocialNetwork sn = new SocialNetwork();
		int nbTests = 0;
		
		try {
			sn.addMember("BBBB","bbbb","profil de test");
			sn.addMember("Paul","paul","profil de paul");
		}
		catch (MemberAlreadyExists e) {
			System.out.println("Il ne devrait pas y avoir de levée d'exception");
			System.exit(0);
		}
		catch (BadEntry e) {
			System.out.println("Il ne devrait pas y avoir de levée d'exception");
			System.exit(0);
		}
		
		try {
			sn.addItemFilm("BBBB", "bbbb", "Star Wars 1","Classique","Lucas","Lucas",200);
			sn.addItemFilm("BBBB", "bbbb", "Star Wars 2","Classique","Lucas","Lucas",200);
		}
		catch (BadEntry e) {
			System.out.println("Il ne devrait pas y avoir de levée d'exception");
			System.exit(0);
		}
		catch (ItemFilmAlreadyExists e) {
			System.out.println("Il ne devrait pas y avoir de levée d'exception");
			System.exit(0);
		}		
		catch (NotMember e) {
			System.out.println("Il ne devrait pas y avoir de levée d'exception");
			System.exit(0);
		}
		
		nbTests++;
		nbErreurs += consultItemBadEntryTest(sn, "BBBB", "bbbb", null, "9.1", "La consultation d'un item alors que le titre n'est pas renseigné est accepté");
		nbTests++;
		nbErreurs += consultItemBadEntryTest(sn, "BBBB", "bbbb", "    ", "9.2", "La consultation d'un item alors que le titre a moins de un caractères autre que les espaces est accepté");
			
		try {
			System.out.println(sn.consultItems("Star Wars 1"));
		}
		catch (BadEntry e) {
			System.out.println("Il ne devrait pas y avoir de levée d'exception");
			System.exit(0);
		}

		
		System.out.println("TestsAddItemBook :   " + nbErreurs + " erreur(s) / " +  nbTests + " tests effectués");
	}

}

package exception;

public class NotMember extends Exception {
	
	public NotMember(String message) {
		super(message);
	}

}

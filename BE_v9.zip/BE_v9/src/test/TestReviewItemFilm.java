package test;

import avis.SocialNetwork;

import exception.BadEntry;
import exception.ItemFilmAlreadyExists;
import exception.MemberAlreadyExists;
import exception.NotItem;
import exception.NotMember;


public class TestReviewItemFilm {

	
	public static int reviewItemFilmBadEntryTest (SocialNetwork sn, String pseudo, String pwd, String titre, float note, String commentaire, String idTest, String messErreur){
		// verifie que l'ajout d'une opinion (pseudo, pwd, profil) est refusee (levee de l'exception BadEntry et  pas de modification du sn)
		// si c'est bien le cas, ne fait rien
		// sinon, affiche le message d'erreur passe en parametre
		int nbFilms = sn.nbFilms();
		try {
			sn.reviewItemFilm (pseudo, pwd, titre, note, commentaire);
			System.out.println ("Test " + idTest + " : " + messErreur);
			return 1;
		}
		catch (BadEntry e) {
			if (sn.nbFilms() != nbFilms) {
				System.out.println("Test " + idTest + " : l'exception BadEntry a bien été levée mais le nombre de films a été modifié");
				return 1;
			}
			else 
				return 0;
		}
		catch (Exception e) {
			System.out.println ("Test " + idTest + " : exception non prévue. " + e); 
			e.printStackTrace();
			return 1;
		}
	}

	public static int reviewItemFilmOKTest (SocialNetwork sn, String pseudo, String pwd, String titre, float note, String commentaire, String idTest){
		//retourne 1 pour une opinion qui n'a pas ete creee ou non modifiee
		//retourne 0 sinon
		try{
			String str = sn.toString(); // Je récupère l'état du SN 
			sn.reviewItemFilm (pseudo, pwd, titre, note, commentaire);
			
			//je verifie que le SN a ete modifie, alors cela implique une modification de l'opinion
			if(!sn.toString().equals(str)) {
				return 0;
			}
			else{
				System.out.println("Le social network n'a pas ete modifie donc l'erreur n'a pas ete relevee. Test " + idTest);
				return 1;
			}
		}
		catch (Exception e) {
			System.out.println ("Test " + idTest + " : exception non prévue. " + e); 
			e.printStackTrace();
			return 1;
		}
	}

	public static int reviewItemFilmNotMemberTest (SocialNetwork sn, String pseudo, String pwd, String titre, float note, String commentaire, String idTest, String messErreur){
		int nbFilms = sn.nbFilms();
		try {
			sn.reviewItemFilm (pseudo, pwd, titre, note, commentaire);
			System.out.println ("Test " + idTest + " : " + messErreur);
			return 1;
		}
		catch (NotMember e) {
			if (sn.nbFilms() != nbFilms) {
				System.out.println("Test " + idTest + " : l'exception NotMember a bien été levée mais le nombre de films a été modifié");
				return 1;
			}
			else
				return 0;
		}
		catch (Exception e) {
			System.out.println ("Test " + idTest + " : exception non prévue. " + e); 
			e.printStackTrace();
			return 1;
		}
	}
	
	public static int reviewItemFilmNotItemTest (SocialNetwork sn, String pseudo, String pwd, String titre, float note, String commentaire, String idTest, String messErreur){
		int nbFilms = sn.nbFilms();
		try {
			sn.reviewItemFilm (pseudo, pwd, titre, note, commentaire);
			System.out.println ("Test " + idTest + " : " + messErreur);
			return 1;
		}
		catch (NotItem e) {
			if (sn.nbFilms() != nbFilms) {
				System.out.println("Test " + idTest + " : l'exception MemberAlreadyExists a bien été levée mais le nombre de films a été modifié");
				return 1;
			}
			else
				return 0;
		}
		catch (Exception e) {
			System.out.println ("Test " + idTest + " : exception non prévue. " + e); 
			e.printStackTrace();
			return 1;
		}
	}




	public static void main(String[] args) {

		int nbFilms = 0;

		int nbTests = 0;
		int nbErreurs = 0;
		
		System.out.println("Tests pour l'ajout d'opinions sur un film.");


		SocialNetwork sn = new SocialNetwork();

		// tests de reviewItemFilm
		nbFilms = sn.nbFilms();

		// <=> fiche numéro 5

		// tentative d'ajout de membres avec entrées "incorrectes"

		try {
			sn.addMember("BBBB","bbbb","profil de test");
			sn.addMember("Paul","paul","profil de paul");
			sn.addMember("Antoine","antoine","profil d'antoine");
			sn.addMember("Alice","alice","profil d'alice");
		}
		catch (MemberAlreadyExists e) {
			System.out.println("Il ne devrait pas y avoir de levée d'exception");
			System.exit(0);
		}
		catch (BadEntry e) {
			System.out.println("Il ne devrait pas y avoir de levée d'exception");
			System.exit(0);
		}
		
		try {
			sn.addItemFilm("BBBB", "bbbb", "Star Wars 1","Classique","Lucas","Lucas",200);
			sn.addItemFilm("BBBB", "bbbb", "Star Wars 2","Classique","Lucas","Lucas",200);
			sn.addItemFilm("BBBB", "bbbb", "Star Wars 3","Classique","Lucas","Lucas",200);
			sn.addItemFilm("BBBB", "bbbb", "Star Wars 4","Classique","Lucas","Lucas",200);
		}
		catch (BadEntry e) {
			System.out.println("Il ne devrait pas y avoir de levée d'exception");
			System.exit(0);
		}
		catch (ItemFilmAlreadyExists e) {
			System.out.println("Il ne devrait pas y avoir de levée d'exception");
			System.exit(0);
		}		
		catch (NotMember e) {
			System.out.println("Il ne devrait pas y avoir de levée d'exception");
			System.exit(0);
		}
		
		
		nbTests++;
		nbErreurs += reviewItemFilmBadEntryTest ( sn, null, "qsdfgh", "Star Wars 1", 4, "Ce film est extraordinaire !", "5.1", "L'ajout d'une opinion dont le pseudo n'est pas instancié est accepté");
		nbTests++;
		nbErreurs += reviewItemFilmBadEntryTest ( sn, " ", "qsdfgh", "Star Wars 1", 4, "Ce film est extraordinaire !", "5.2", "L'ajout d'une opinion dont le pseudo ne contient pas un caracteres, autre que des espaces, est accepté");
		nbTests++;
		nbErreurs += reviewItemFilmBadEntryTest ( sn, "B", null, "Star Wars 1", 4, "Ce film est extraordinaire !", "5.3", "L'ajout d'une opinion dont le password n'est pas instancié est accepté");
		nbTests++;
		nbErreurs += reviewItemFilmBadEntryTest ( sn, "B", "   qwd ", "Star Wars 1", 4, "Ce film est extraordinaire !", "5.4", "L'ajout d'une opinion dont le password ne contient pas au moins 4 caracteres, autre que des espaces de début ou de fin, est accepté");
		nbTests++;
		nbErreurs += reviewItemFilmBadEntryTest ( sn, "BBBB", "bbbb", null, 4, "Ce film est extraordinaire !", "5.5", "L'ajout d'une opinion dont le titre du film n'est pas instancié est accepté");
		nbTests++;
		nbErreurs += reviewItemFilmBadEntryTest ( sn, "BBBB", "bbbb", "    ", 4, "Ce film est extraordinaire !", "5.6", "L'ajout d'une opinion dont le titre du film ne contenant que des espaces est accepté");
		nbTests++;
		nbErreurs += reviewItemFilmBadEntryTest ( sn, "BBBB", "bbbb", "Star Wars 1",-3, "Ce film est extraordinaire !", "5.7", "L'ajout d'une opinion dont la note est négative est accepté");
		nbTests++;
		nbErreurs += reviewItemFilmBadEntryTest ( sn, "BBBB", "bbbb", "Star Wars 1", 7, "Ce film est extraordinaire !", "5.8", "L'ajout d'une opinion dont la note est supérieure à 5 est accepté");
		nbTests++;
		nbErreurs += reviewItemFilmBadEntryTest ( sn, "BBBB", "bbbb", "Star Wars 1", 4, null, "5.9", "L'ajout d'une opinion dont le commentaire n'est pas instancié est accepté");
		

		// <=> fiche numéro 6

		// ajout de 3 films avec des paramètres d'entrées corrects

		nbTests++;
		nbErreurs += reviewItemFilmOKTest (sn, "Paul", "paul", "Star Wars 1", 4, "Ce film est extraordinaire !", "6.1a");
		nbTests++;
		nbErreurs += reviewItemFilmOKTest (sn, "Antoine", "antoine", "Star Wars 2", 3.5f, "Ce film est magique !", "6.1b");
		nbTests++;
		nbErreurs += reviewItemFilmOKTest (sn, "Alice", "alice", "Star Wars 3", 5, "Ce film est éprouvant !", "6.1c");
		//le membre Paul commente le meme film, mais modifie son opinion
		nbTests++;
		nbErreurs += reviewItemFilmOKTest (sn, "Paul", "paul", "Star Wars 1", 1, "Je n'ai pas aimé ce film", "6.2");
		
		// Test de l'ajout d'un avis sur un film non existant
		nbTests++;
		nbErreurs += reviewItemFilmNotItemTest (sn, "Paul", "paul", "Star Wars 5", 4, "Bonne lecture de chevet", "6.3","L'ajout d'un commentaire sur un film non existant est accepte");
		nbTests++;
		nbErreurs += reviewItemFilmNotMemberTest (sn, "Julien", "julien", "Star Wars 1", 5, "Ce film est emouvant !", "6.4","L'ajout d'un commentaire alors que le pseudo et le password du membre ne correspondent pas est accepte");
		nbTests++;
		nbErreurs += reviewItemFilmNotMemberTest (sn, "Alice", "wrongpassword", "Star Wars 1", 5, "Ce film est emouvant !", "6.5","L'ajout d'un commentaire lorque le password n'est pas correct est accepté");

	

		System.out.println(sn);

		//bilan du test de addReviewFilm
		System.out.println("TestsAddReviewFilm :   " + nbErreurs + " erreur(s) / " +  nbTests + " tests effectués");

		// ajouts au bilan en cours si le bilan est passé en paramètre
        if ((args != null) && (args.length == 2)) {        
           nbTests = nbTests + new Integer(args[0]);
           nbErreurs = nbErreurs + new Integer(args[1]);       
           args[0] = "" + nbTests;
           args[1] = "" + nbErreurs;
        }
        
    }  // fin du main
	
	
}
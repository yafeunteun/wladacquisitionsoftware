package avis;


import java.util.LinkedList;

import exception.BadEntry;


public abstract class Item {

	/**
	 * @uml.property  name="titre"
	 */
	protected String titre;

	/**
	 * @uml.property  name="genre"
	 */
	protected String genre;

		/** 
		 * @uml.property name="mesOpinions"
		 * @uml.associationEnd multiplicity="(0 -1)" inverse="monItem:avis.Opinion"
		 */
	protected LinkedList <Opinion> mesOpinions;

	/**
	 * constructeur de <Item>
	 * @param pseudo
	 * @param password
	 * @param titre
	 * @param genre
	 * @param auteur
	 * @param nbPages
	 */
	public Item(String titre, String genre) throws BadEntry{
		//tests sur le titre et genre
		if ((titre == null) || (genre == null))
			throw new BadEntry("le titre et/ou le genre ne sont pas instancies");
		if(titre.trim().length()<1)
			throw new BadEntry("le titre contient moins de 1 caractere autres que des espaces");
		
		mesOpinions = new LinkedList <Opinion> ();
		this.titre = titre.trim();
		this.genre = genre;
	}
	
	
		/**
		 * 
		 */
		public boolean titleExists(String titre){
			//retourne vrai pour un titre déjà existant
			return this.titre.equalsIgnoreCase(titre.trim());
		}
	
		/**
		 */
		public float calculMoyenne(){
			float nouvelMoyenne = 0.0f;
			for(Opinion opinion : mesOpinions) {
				nouvelMoyenne += opinion.getNote();
			}
			nouvelMoyenne /= mesOpinions.size();
			return nouvelMoyenne;
		}
			
		/**
		 */
		public abstract String toString();


		public boolean equals(Item item){
			return this.titre.trim().equalsIgnoreCase(item.titre.trim());
		}
		
		public void addOpinion(Opinion nouvelOpinion){
			mesOpinions.add(nouvelOpinion);
		}

								
		/**
		 */
		public void main(){
		}

}

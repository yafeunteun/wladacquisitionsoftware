package avis;

import java.util.LinkedList;


import exception.BadEntry;
import exception.ItemFilmAlreadyExists;
import exception.ItemBookAlreadyExists;
import exception.MemberAlreadyExists;
import exception.NotItem;
import exception.NotMember;

/** 
 * @author A. Beugnard, 
 * @author G. Ouvradou
 * @author B. Prou
 * @date février - mars 2011
 * @version V0.6
 */


/** 
 * <p>
 * <b>Système de mutualisation d'opinions portant sur des domaines
 * variés (littérature, cinéma, art, gastronomie, etc.) et non limités.</b>
 * </p>
 * <p>
 * L'accès aux items et aux opinions qui leurs sont associées
 * est public. La création d'item et le dépôt d'opinion nécessite en revanche 
 * que l'utilisateur crée son profil au préalable.
 * </p>
 * <p>
 * Lorsqu'une méthode peut lever deux types d'exception, et que les conditions sont réunies 
 * pour lever l'une et l'autre, rien ne permet de dire laquelle des deux sera effectivement levée.
 * </p>
 * <p>
 * Dans une version avancée (version 2), une opinion peut également
 * être évaluée. Chaque membre se voit dans cette version décerner un "karma" qui mesure
 * la moyenne des notes portant sur les opinions qu'il a émises.
 * L'impact des opinions entrant dans le calcul de la note moyenne attribuée à un item
 * est pondéré par le karma des membres qui les émettent.
 * </p>
 */

public class SocialNetwork {

	/** 
	 * @uml.property name="myMovies"
	 * @uml.associationEnd multiplicity="(0 -1)" inverse="socialNetwork:avis.Film"
	 */
	private LinkedList <Film> myMovies;


	/** 
	 * @uml.property name="myBooks"
	 * @uml.associationEnd multiplicity="(0 -1)" inverse="socialNetwork:avis.Book"
	 */
	private LinkedList <Book> myBooks;


	/** 
	 * @uml.property name="myMembers"
	 * @uml.associationEnd multiplicity="(0 -1)" inverse="socialNetwork:avis.Membre"
	 */
	private LinkedList <Membre> myMembers;
	

	/**
	 * constructeur de <i>SocialNetwok</i> 
	 * 
	 */
	public SocialNetwork() {
		myMembers = new LinkedList <Membre> ();
		myMovies = new LinkedList <Film> ();
		myBooks = new LinkedList <Book> ();
	}

	/**
	 * Obtenir le nombre de membres du <i>SocialNetwork</i>
	 * 
	 * @return le nombre de membres
	 */
	public int nbMembers() {
		return myMembers.size();
	}

	/**
	 * Obtenir le nombre de films du <i>SocialNetwork</i>
	 * 
	 * @return le nombre de films
	 */
	public int nbFilms() {
		return myMovies.size();
	}

	/**
	 * Obtenir le nombre de livres du <i>SocialNetwork</i>
	 * 
	 * @return le nombre de livres
	 */
	public int nbBooks() {
		return myBooks.size();
	}


	/**
	 * Ajouter un nouveau membre au <i>SocialNetwork</i>
	 * 
	 * @param pseudo son pseudo
	 * @param password son mot de passe 
	 * @param profil un slogan choisi par le membre pour se définir
	 * 
	 * @throws BadEntry :
	 * <ul>
	 *  <li>  si le pseudo n'est pas instancié ou a moins de 1 caractère autre que des espaces .  </li>
	 *  <li>  si le password n'est pas instancié ou a moins de 4 caractères autres que des leadings or trailing blanks. </li>
	 *  <li>  si le profil n'est pas instancié.  </li>
	 * </ul><br>       
	 * 
	 * @throws MemberAlreadyExists membre de même pseudo déjà présent dans le <i>SocialNetwork</i> (même pseudo : indifférent à  la casse  et aux leadings et trailings blanks)
	 * 
	 */
	public void addMember(String pseudo, String password, String profil) throws BadEntry, MemberAlreadyExists  {
		
		Membre.testsPseudoPwd(pseudo, password);
		if (profil == null)
			throw new BadEntry("le profil n'est pas instancie");
		for (Membre mb : myMembers){
			if(mb.pseudoExists(pseudo)) {
				throw new MemberAlreadyExists();
			}
		}
		//ajout du membre, si aucune erreur relevee
		Membre m = new Membre(pseudo, password, profil);
		myMembers.add(m);
	}


	/**
	 * Ajouter un nouvel item de film au <i>SocialNetwork</i> 
	 * 
	 * @param pseudo le pseudo du membre
	 * @param password le password du membre 
	 * @param titre le titre du film
	 * @param genre son genre (aventure, policier, etc.)
	 * @param realisateur le réalisateur
	 * @param scenariste le scénariste
	 * @param duree sa durée en minutes
	 * 
	 * @throws BadEntry :
	 * <ul>
	 *  <li>  si le pseudo n'est pas instancié ou a moins de 1 caractère autre que des espaces .  </li>
	 *  <li>  si le password n'est pas instancié ou a moins de 4 caractères autres que des leadings or trailing blanks. </li>
	 *  <li>  si le titre n'est pas instancié ou a moins de 1 caractère autre que des espaces.  </li>
	 *  <li>  si le genre n'est pas instancié. </li>
	 *  <li>  si le réalisateur n'est pas instancié. </li>
	 *  <li>  si le scénariste n'est pas instancié. </li>
	 *  <li>  si la durée n'est pas positive.  </li>
	 * </ul><br>       
	 * @throws NotMember : si le pseudo n'est pas celui d'un membre ou si le pseudo et le password ne correspondent pas.
	 * @throws ItemFilmAlreadyExists : item film de même titre  déjà présent (même titre : indifférent à  la casse  et aux leadings et trailings blanks)
	 * 
	 */
	public void addItemFilm(String pseudo, String password, String titre, String genre, String realisateur, String scenariste, int duree) throws BadEntry, NotMember, ItemFilmAlreadyExists {
		//tests
		Membre.testsPseudoPwd(pseudo, password);
		Membre.isMember(pseudo, password, myMembers);
		Film f = new Film(titre, genre, realisateur, scenariste, duree);
		//item film de meme titre deja present ?
		for (Film movie : myMovies){
			if(movie.titleExists(titre)) 
			{
				throw new ItemFilmAlreadyExists();
			}
		}
		//ajoute le livre si aucune erreur
		myMovies.add(f);
	}

	/**
	 * Ajouter un nouvel item de livre au <i>SocialNetwork</i> 
	 * 
	 * @param pseudo le pseudo du membre
	 * @param password le password du membre 
	 * @param titre le titre du livre
	 * @param genre son genre (roman, essai, etc.)
	 * @param auteur l'auteur
	 * @param nbPages le nombre de pages
	 * 
	 * @throws BadEntry :
	 * <ul>
	 *  <li>  si le pseudo n'est pas instancié ou a moins de 1 caractère autre que des espaces .  </li>
	 *  <li>  si le password n'est pas instancié ou a moins de 4 caractères autres que des leadings or trailing blanks. </li>
	 *  <li>  si le titre n'est pas instancié ou a moins de 1 caractère autre que des espaces.  </li>
	 *  <li>  si le genre n'est pas instancié. </li>
	 *  <li>  si l'auteur n'est pas instancié. </li>
	 *  <li>  si le nombre de pages n'est pas positif.  </li>
	 * </ul><br>       
	 * @throws NotMember : si le pseudo n'est pas celui d'un membre ou si le pseudo et le password ne correspondent pas.
	 * @throws ItemBookAlreadyExists item livre de même titre  déjà présent (même titre : indifférent à la casse  et aux leadings et trailings blanks)
	 * 
	 * 
	 */
	public void addItemBook(String pseudo, String password, String titre, String genre, String auteur, int nbPages) throws  BadEntry, NotMember, ItemBookAlreadyExists{
		//tests
		Membre.testsPseudoPwd(pseudo, password);
		Membre.isMember(pseudo, password, myMembers);
		Book b = new Book(titre, genre,auteur,nbPages);
		//item livre de meme titre deja present ?
		for (Book book : myBooks){
			if(book.titleExists(titre)) 
			{
				throw new ItemBookAlreadyExists();
			}
		}
		//ajoute le livre si aucune erreur
		myBooks.add(b);
	}
	

	/**
	 * Consulter les items du <i>SocialNetwork</i> par nom
	 * 
	 * @param nom son nom (eg. titre d'un film, d'un livre, etc.)
	 * 
	 * @throws BadEntry : si le nom n'est pas instancié ou a moins de 1 caractère autre que des espaces.  </li>
	 * 
	 * @return LinkedList <String> : la liste des représentations de tous les items ayant ce nom 
	 * Cette représentation contiendra la note de l'item s'il a été noté.
	 * (une liste vide si aucun item ne correspond) 
	 */
	public LinkedList <String> consultItems(String titre) throws BadEntry {
		
		LinkedList <String> item = new LinkedList <String> ();
		
		if ((titre == null)||(titre.trim().length()<1))
			throw new BadEntry("parametre d'entree incorrect");
		
		for (Book book : myBooks){
			if(book.titleExists(titre)) 
			{
				item.add("Livre : " + book.toString());
			}
		}
		for (Film film : myMovies){
			if(film.titleExists(titre)) 
			{
				item.add("Film : " + film.toString());
			}
		}
		return item;
	}



	/**
	 * Donner son opinion sur un item film.
	 * Ajoute l'opinion de ce membre sur ce film au <i>SocialNetwork</i> 
	 * Si une opinion de ce membre sur ce film  préexiste, elle est mise à jour avec ces nouvelles valeurs.
	 * 
	 * @param pseudo pseudo du membre émettant l'opinion
	 * @param password son mot de passe
	 * @param titre titre du film  concerné
	 * @param note la note qu'il donne au film 
	 * @param commentaire ses commentaires
	 * 
	 * @throws BadEntry :
	 * <ul>
	 *  <li>  si le pseudo n'est pas instancié ou a moins de 1 caractère autre que des espaces .  </li>
	 *  <li>  si le password n'est pas instancié ou a moins de 4 caractères autres que des leadings or trailing blanks. </li>
	 *  <li>  si le titre n'est pas instancié ou a moins de 1 caractère autre que des espaces.  </li>
	 *  <li>  si la note n'est pas comprise entre 0.0 et 5.0. </li>
	 *  <li>  si le commentaire n'est pas instancié. </li>
	 * </ul><br>       
	 * @throws NotMember : si le pseudo n'est pas celui d'un membre ou si le pseudo et le password ne correspondent pas.
	 * @throws NotItem : si le titre n'est pas le titre d'un film.
	 * 
	 * @return la note moyenne des notes sur ce film  
	 */
	public float reviewItemFilm(String pseudo, String password, String titre, float note, String commentaire) throws BadEntry, NotMember, NotItem {
		Membre.testsPseudoPwd(pseudo, password);
		Opinion.testsAddOpinionValid(titre, note, commentaire);
		Membre member = Membre.isMember(pseudo, password, myMembers);
		Film f = null;
		boolean find = false;
		for (Film movie : myMovies){
			if(movie.titleExists(titre))
			{
				find = true;
				f = movie;
			}
		}
		if(!find)
			throw new NotItem("le titre n'est pas le titre d'un livre");
		
		//ici, on s'assure que le membre est bien non nul !
		if(member != null)
		{
			find = false;
			LinkedList<Opinion> opinionsList = member.getOpinions();
			for(Opinion opinion : opinionsList){
				Item i = opinion.getMonItem();
				if(i instanceof Film){
					if(i.equals(f)) {
						find = true;
						opinion.modifyOpinion(commentaire, note);
					}
				}
			}
			//si j'ai déjà trouvé une opinion sur ce livre, alors je renvoie sa nouvelle moyenne
			if(find) {
				return f.calculMoyenne();
			}
			//sinon, je crée l'opinion et je recalcule sa moyenne
			else {
				Opinion nouvelOpinion = new Opinion(commentaire, note, member, f);
				f.addOpinion(nouvelOpinion);
				member.addOpinion(nouvelOpinion);
				return f.calculMoyenne();
			}
		}
		else
			throw new NotMember("le membre n'est pas instancie");
		
	}



	/**
	 * Donner son opinion sur un item livre.
	 * Ajoute l'opinion de ce membre sur ce livre au <i>SocialNetwork</i> 
	 * Si une opinion de ce membre sur ce livre  préexiste, elle est mise à jour avec ces nouvelles valeurs.
	 * 
	 * @param pseudo pseudo du membre émettant l'opinion
	 * @param password son mot de passe
	 * @param titre titre du livre  concerné
	 * @param note la note qu'il donne au livre 
	 * @param commentaire ses commentaires
	 * 
	 * @throws BadEntry :
	 * <ul>
	 *  <li>  si le pseudo n'est pas instancié ou a moins de 1 caractère autre que des espaces .  </li>
	 *  <li>  si le password n'est pas instancié ou a moins de 4 caractères autres que des leadings or trailing blanks. </li>
	 *  <li>  si le titre n'est pas instancié ou a moins de 1 caractère autre que des espaces.  </li>
	 *  <li>  si la note n'est pas comprise entre 0.0 et 5.0. </li>
	 *  <li>  si le commentaire n'est pas instancié. </li>
	 * </ul><br>       
	 * @throws NotMember : si le pseudo n'est pas celui d'un membre ou si le pseudo et le password ne correspondent pas.
	 * @throws NotItem : si le titre n'est pas le titre d'un livre.
	 * 
	 * @return la note moyenne des notes sur ce livre
	 */
	public float reviewItemBook(String pseudo, String password, String titre, float note, String commentaire) throws BadEntry, NotMember, NotItem {
		Membre.testsPseudoPwd(pseudo, password);
		Opinion.testsAddOpinionValid(titre, note, commentaire);
		Membre member = Membre.isMember(pseudo, password, myMembers);
		Book b = null;
		boolean find = false;
		for (Book book : myBooks){
			if(book.titleExists(titre))
			{
				find = true;
				b = book;
			}
		}
		if(!find)
			throw new NotItem("le titre n'est pas le titre d'un livre");
		
		//ici, on s'assure que le membre est bien non nul !
		if(member != null)
		{
			find = false;
			LinkedList<Opinion> opinionsList = member.getOpinions();
			for(Opinion opinion : opinionsList){
				Item i = opinion.getMonItem();
				if(i instanceof Book){
					if(i.equals(b)) {
						find = true;
						opinion.modifyOpinion(commentaire, note);
					}
				}
			}
			//si j'ai déjà trouvé une opinion sur ce livre, alors je renvoie sa nouvelle moyenne
			if(find) {
				return b.calculMoyenne();
			}
			//sinon, je crée l'opinion et je recalcule sa moyenne
			else {
				Opinion nouvelOpinion = new Opinion(commentaire, note, member, b);
				b.addOpinion(nouvelOpinion);
				member.addOpinion(nouvelOpinion);
				return b.calculMoyenne();
			}
		}
		else
			throw new NotMember("le membre n'est pas instancie");
	}


	/**
	 * Obtenir une représentation textuelle du <i>SocialNetwork</i>.
	 * 
	 * @return la chaîne de caractères représentation textuelle du <i>SocialNetwork</i> 
	 */
	public String toString() {
		String message = "";
		for(Membre membre : myMembers){
			message += membre.toString() + "\n";
		}
		for(Book book : myBooks){
			message += "\n" + book.toString() + "\n";
		}
		for(Film film : myMovies){
			message += "\n" + film.toString() + "\n";
		}
			
		return message;
	}

		
		/**
		 */
		public void reviewOpinionBook(){
		}

			
			/**
			 */
			public void reviewOpinionFilm(){
			}

}

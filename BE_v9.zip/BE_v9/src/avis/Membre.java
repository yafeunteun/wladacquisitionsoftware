package avis;


import java.util.LinkedList;

import exception.BadEntry;
import exception.NotMember;


public class Membre {

	/** 
	 * @uml.property name="pseudo"
	 */
	private String pseudo;

	/** 
	 * @uml.property name="password"
	 */
	private String password;

	/** 
	 * @uml.property name="profil"
	 */
	private String profil;

	/** 
	 * @uml.property name="mesOpinions"
	 * @uml.associationEnd multiplicity="(0 -1)" ordering="true" inverse="monMembre:java.util.LinkedList"
	 */
	private LinkedList <Opinion> mesOpinions;

	/**
	 * @uml.property  name="karma"
	 * Moyenne des notes attribuées aux opinions données par le membre
	 * comprise entre 1 et 5
	 */
	private float karma = 3.0f;
	
	
	/**
	 * constructeur de <i>Membre</i> 
	 * 
	 */
	public Membre(String pseudo, String password, String profil) throws BadEntry{
		mesOpinions = new LinkedList <Opinion> ();
		this.pseudo = pseudo.trim();
		this.password = password;
		this.profil = profil;
	}

		
		/**
		 */
		/*public boolean goodEntries(String pseudo, String password, String profil){
			return false;
		}*/
		
		/**
		 */
		public boolean pseudoExists(String pseudo){
			//retourne vrai pour un pseudo déjà existant
			return this.pseudo.equalsIgnoreCase(pseudo.trim());
		}
		
		/**
		 */
		public boolean matchesPwd (String password){
			//retourne vrai si le password correspond
			return this.password.equals(password);
		}
		
		
		/**
		 * Teste si le pseudo et le password sont instancies,
		 * si le pseudo contient moins de 1 caractere autres que des espaces,
		 * et si le password contient moins de 4 caracteres autres que des espaces
		 * 
		 * @return true si le membre existe
		 */
		public static Membre isMember(String pseudo, String password, LinkedList<Membre> myMembers) throws NotMember{
			//si le pseudo n'est pas celui d'un membre
			Membre m = null;
			boolean existingPseudo = false;
			for (Membre mb : myMembers){
				if(mb.pseudoExists(pseudo)) 
				{
					m = mb;
					existingPseudo = true;
					//si le pseudo et le password ne correspondent pas
					if (!mb.matchesPwd(password))
						throw new NotMember("Le pseudo et le password ne correspondent pas");
				}
			}
			if (!existingPseudo)
				throw new NotMember("Le pseudo n'est pas celui d'un membre");
			//retourne le membre existant
			return m;
		}
		
		/**
		 * Teste si le pseudo et le password sont instancies,
		 * si le pseudo contient moins de 1 caractere autres que des espaces,
		 * et si le password contient moins de 4 caracteres autres que des espaces
		 * 
		 */
		public static void testsPseudoPwd(String pseudo, String password) throws BadEntry{
			if ((pseudo == null) || (password == null))
				throw new BadEntry("le pseudo et/ou le password ne sont pas instancies");
			if (pseudo.trim().length()<1)
				throw new BadEntry("le pseudo contient moins de 1 caractere autres que des espaces"); 
			if(password.trim().length()<4)
				throw new BadEntry("le password contient moins de 4 caracteres autres que des espaces");
		}
		
		public void addOpinion(Opinion nouvelOpinion){
			mesOpinions.add(nouvelOpinion);
		}
		
		
		public LinkedList<Opinion> getOpinions(){
			return mesOpinions;
		}
		
		
		/**
		 */
		public boolean equals(Membre membre){
			return false;	
		}
		
		/**
		 * méthode toString
		 * @return password, pseudo et profil du membre
		 */
		public String toString() {
			return "Le membre a pour pseudo : "+this.pseudo+" (password : "+this.password+"). Son profil : "+this.profil;
		}
		
		
		/**
		 */
		public void main(){
		}


}

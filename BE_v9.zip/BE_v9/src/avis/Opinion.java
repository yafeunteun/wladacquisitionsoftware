package avis;

import exception.BadEntry;


public class Opinion {

	/** 
	 * @uml.property name="note"
	 */
	private float note;

	/** 
	 * @uml.property name="commentaire"
	 */
	private String commentaire;

	/** 
	 * @uml.property name="monMembre"
	 * @uml.associationEnd multiplicity="(1 1)" inverse="mesOpinions:avis.Membre"
	 */
	private Membre monMembre = null;

	/**
	 * @uml.property  name="monItem"
	 * @uml.associationEnd  multiplicity="(1 1)" inverse="mesOpinions:avis.Item"
	 */
	private Item monItem = null;
	
	/**	 
	 * @uml.property  name="moyenneOpinion"
	 * 
	 */
	private float moyenneOpinion;
	
	
	//constructeur
	public Opinion(String commentaire, float note, Membre monMembre, Item monItem){
		this.commentaire = commentaire;
		this.note = note;
		this.monMembre = monMembre;
		this.monItem = monItem;
	}
	
	//faire une méthode static pour tester commentaire et note
	
	
	public Item getMonItem(){
		return monItem;
	}
	
	public void modifyOpinion(String commentaire, float note){
		this.commentaire = commentaire;
		this.note = note;
	}
	
	public float getNote(){
		return note;
	}
	
	public static void testsAddOpinionValid(String titre, float note, String commentaire) throws BadEntry{
		if((titre == null) || (titre.trim().length()<1))
			throw new BadEntry("le titre n'est pas instancie ou a moins de 1 caractere autre que des espaces");
		if((note < 0.0) || (note > 5.0))
			throw new BadEntry("la note n'est pas comprise entre 0.0 et 5.0");
		if(commentaire == null)
			throw new BadEntry("le commentaire n'est pas instancie");
	}
	
	
	/**
	 * méthode toString
	 * @return commentaire et note de l'opinion
	 */
	public String toString() {
		return "Le commentaire est : "+this.commentaire+" et la note est : "+this.note;
	}

			
		/**
		 */
		public void main(){
		}


}

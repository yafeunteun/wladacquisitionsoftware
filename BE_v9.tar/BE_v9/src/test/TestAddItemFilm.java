package test;

	import java.util.LinkedList;

	import avis.SocialNetwork;

	import exception.BadEntry;
	import exception.ItemFilmAlreadyExists;
import exception.MemberAlreadyExists;
import exception.NotMember;

	/** 
	 * @author B. Prou, E. Cousin
	 * @date mars 2015
	 * @version V1.0
	 */
public class TestAddItemFilm {
		public static int addFilmBadEntryTest (SocialNetwork sn, String pseudo, String pwd, String titre, String genre, String realisateur, String scenariste, int duree, String idTest, String messErreur){
			// vérifie que l'ajout d'un film (pseudo, pwd, titre, auteur, genre) est refusée (levée de l'exception BadEntry et  pas de modification du sn)
			// si c'est bien le cas, ne fait rien
			// sinon, affiche le message d'erreur passé en paramètre
			int nbFilms = sn.nbFilms();
			try {
				sn.addItemFilm (pseudo, pwd, titre, genre, realisateur, scenariste, duree);
				System.out.println ("Test " + idTest + " : " + messErreur);
				return 1;
			}
			catch (BadEntry e) {
				if (sn.nbFilms() != nbFilms) {
					System.out.println("Test " + idTest + " : l'exception BadEntry a bien été levée mais le nombre de films a été modifié");
					return 1;
				}
				else 
					return 0;
			}
			catch (Exception e) {
				System.out.println ("Test " + idTest + " : exception non prévue. " + e); 
				e.printStackTrace();
				return 1;
			}
		}

		public static int addFilmOKTest (SocialNetwork sn, String pseudo, String pwd, String titre, String genre, String realisateur, String scenariste, int duree, String idTest){
			int nbFilms = sn.nbFilms();
			try{
				sn.addItemFilm (pseudo, pwd, titre, genre, realisateur, scenariste, duree);
				if (sn.nbFilms() != nbFilms+1) {
					System.out.println("Test " + idTest + " :  le nombre de films n'a pas été correctement incrémenté");
					return 1;
				}
				else 
					return 0;
			}
			catch (Exception e) {
				System.out.println ("Test " + idTest + " : exception non prévue. " + e); 
				e.printStackTrace();
				return 1;
			}
		}

		public static int addItemFilmAlreadyExistsTest (SocialNetwork sn, String pseudo, String pwd, String titre, String genre, String realisateur, String scenariste, int duree, String idTest, String messErreur){
			int nbFilms = sn.nbFilms();
			try {
				sn.addItemFilm (pseudo, pwd, titre, genre, realisateur, scenariste, duree);
				System.out.println ("Test " + idTest + " : " + messErreur);
				return 1;
			}
			catch (ItemFilmAlreadyExists e) {
				if (sn.nbFilms() != nbFilms) {
					System.out.println("Test " + idTest + " : l'exception ItemFilmAlreadyExists a bien été levée mais le nombre de films a été modifié");
					return 1;
				}
				else
					return 0;
			}
			catch (Exception e) {
				System.out.println ("Test " + idTest + " : exception non prévue. " + e); 
				e.printStackTrace();
				return 1;
			}
		}
		
		public static int addItemFilmNotMemberTest (SocialNetwork sn, String pseudo, String pwd, String titre, String genre, String realisateur, String scenariste, int duree, String idTest, String messErreur){
			int nbFilms = sn.nbFilms();
			try {
				sn.addItemFilm (pseudo, pwd, titre, genre, realisateur, scenariste, duree);
				System.out.println ("Test " + idTest + " : " + messErreur);
				return 1;
			}
			catch (NotMember e) {
				if (sn.nbFilms() != nbFilms) {
					System.out.println("Test " + idTest + " : l'exception ItemFilmAlreadyExists a bien été levée mais le nombre de films a été modifié");
					return 1;
				}
				else
					return 0;
			}
			catch (Exception e) {
				System.out.println ("Test " + idTest + " : exception non prévue. " + e); 
				e.printStackTrace();
				return 1;
			}
		}



		public static void main(String[] args) {

			int nbLivres = 0;
			int nbFilms = 0;

			int nbTests = 0;
			int nbErreurs = 0;
			
			System.out.println("Tests ajouter des films au réseau social  ");


			SocialNetwork sn = new SocialNetwork();

			nbFilms = sn.nbFilms();

			// <=> fiche numéro 3

			// tentative d'ajout de films avec entrées "incorrectes"
			
			try {
					sn.addMember("BBBB","bbbb","profil de test");
					sn.addMember("Paul","paul","profil de paul");
					sn.addMember("Antoine","antoine","profil d'antoine");
					sn.addMember("Alice","alice","profil d'alice");
			}
			catch (MemberAlreadyExists e) {
					System.out.println("Il ne devrait pas y avoir de levée d'exception");
					System.exit(0);
				}
			catch (BadEntry e) {
				System.out.println("Il ne devrait pas y avoir de levée d'exception");
				System.exit(0);
			}

			nbTests++;
			nbErreurs += addFilmBadEntryTest ( sn, null, "qsdfgh", "titre","genre","realisateur","scenariste",5, "3.1", "L'ajout d'un film par un membre dont le pseudo n'est pas instancié est accepté");
			nbTests++;
			nbErreurs += addFilmBadEntryTest ( sn, " ", "qsdfgh", "titre","genre","realisateur","scenariste",5, "3.2", "L'ajout d'un film par un membre dont le pseudo ne contient pas un caracteres, autre que des espaces, est accepté");
			nbTests++;
			nbErreurs += addFilmBadEntryTest ( sn, "B", null, "titre","genre","realisateur","scenariste",5, "3.3", "L'ajout d'un film par un membre dont le password n'est pas instancié est accepté");
			nbTests++;
			nbErreurs += addFilmBadEntryTest ( sn, "B", "   qwd ", "titre","genre","realisateur","scenariste",5, "3.4", "L'ajout d'un film par un membre dont le password ne contient pas au moins 4 caracteres, autre que des espaces de début ou de fin, est accepté");
			nbTests++;
			nbErreurs += addFilmBadEntryTest ( sn, "BBBB", "bbbb", null,"genre","realisateur","scenariste",5, "3.5", "L'ajout d'un film dont le titre n'est pas instancié est accepté");
			nbTests++;
			nbErreurs += addFilmBadEntryTest ( sn, "BBBB", "bbbb", "    ","genre","realisateur","scenariste",5, "3.6", "L'ajout d'un film dont le titre ne contient que des espaces est accepté");
			nbTests++;
			nbErreurs += addFilmBadEntryTest ( sn, "BBBB", "bbbb", "titre",null,"realisateur","scenariste",5, "3.7", "L'ajout d'un film dont le genre n'est pas instancié est accepté");
			nbTests++;
			nbErreurs += addFilmBadEntryTest ( sn, "BBBB", "bbbb", "titre","genre",null,"scenariste",5, "3.8", "L'ajout d'un film dont le realisateur n'est pas instancié est accepté");
			nbTests++;
			nbErreurs += addFilmBadEntryTest ( sn, "BBBB", "bbbb", "titre","genre","realisateur",null,5, "3.9", "L'ajout d'un film dont le scenariste n'est pas instancié est accepté");
			nbTests++;
			nbErreurs += addFilmBadEntryTest ( sn, "BBBB", "bbbb", "titre","genre","realisateur","scenariste",-5, "3.10", "L'ajout d'un film dont la duree est négative est accepté");


			// <=> fiche numéro 2

			// ajout de 3 films avec entrées "correctes"

			nbTests++;
			nbErreurs += addFilmOKTest (sn, "Paul", "paul", "Star Wars 1","Classique","Lucas","Lucas",200,"4.1a");
			nbFilms++;
			nbTests++;
			nbErreurs += addFilmOKTest (sn, "Antoine", "antoine", "Star Wars 2","Classique","Lucas","Lucas",300,"4.1b");
			nbFilms++;
			nbTests++;
			nbErreurs += addFilmOKTest (sn, "Alice", "alice", "Star Wars 3","Classique","Lucas","Lucas",500,"4.1c");
			nbFilms++;
			// tentative d'ajout de membre "existant"
			nbTests++;
			nbErreurs += addItemFilmAlreadyExistsTest(sn, "Paul", "paul","Star Wars 1","Classique","Lucas","Lucas",200, "4.2", "L'ajout d'un film possédant le même titre que le premier film ajouté est accepté");
			nbTests++;
			nbErreurs += addItemFilmAlreadyExistsTest(sn, "Paul", "paul","Star Wars 3","Classique","Lucas","Lucas",500, "4.3", "L'ajout d'un film possédant le même titre que le dernier film ajouté est accepté");
			nbTests++;
			nbErreurs += addItemFilmAlreadyExistsTest(sn, "Paul", "paul","star wars 3","Classique","Lucas","Lucas",500, "4.4", "L'ajout d'un film possédant le même titre qu'un film existant(mais avec une casse différente est accepté");
			nbTests++;
			nbErreurs += addItemFilmAlreadyExistsTest(sn, "Paul", "paul","      Star Wars 3","Classique","Lucas","Lucas",500, "4.5", "L'ajout d'un film possédant le même titre qu'un film existant(mais avec trailing blanks et leading) est accepté");		
			nbTests++;
			nbErreurs += addItemFilmNotMemberTest(sn, "Julien", "paul","titre","genre","realisateur","scenariste",100, "4.6", "L'ajout d'un film par un non membre est accepté");		
			nbTests++;
			nbErreurs += addItemFilmNotMemberTest(sn, "Paul", "wrongpassword","titre","genre","realisateur","scenariste",100, "4.7", "L'ajout d'un film lorsque le pseudo et le password ne correspondent pas est accepté");		


			nbTests++;
			if (nbFilms != sn.nbFilms()) {
				System.out.println("Erreur  :  le nombre de films ne correspond pas au nombre d'ajouts par addFilmOKTest");	
				nbErreurs++;
			}

			// ce n'est pas du test, mais cela peut "rassurer"...
			System.out.println(sn);

			// bilan du test de addItemFilm
			System.out.println("TestsAddItemFilm :   " + nbErreurs + " erreur(s) / " +  nbTests + " tests effectués");

			// ajouts au bilan en cours si le bilan est passé en paramètre
	         if ((args != null) && (args.length == 2)) {        
	            nbTests = nbTests + new Integer(args[0]);
	            nbErreurs = nbErreurs + new Integer(args[1]);       
	            args[0] = "" + nbTests;
	            args[1] = "" + nbErreurs;
	         }
	         
	     }  // fin du main

}

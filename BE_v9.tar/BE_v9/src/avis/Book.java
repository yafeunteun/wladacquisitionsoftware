package avis;

import exception.BadEntry;


public class Book extends Item {

	/** 
	 * @uml.property name="auteur"
	 */
	private String auteur;

	/** 
	 * @uml.property name="nbPages"
	 */
	private int nbPages;

	/**
	 * constructeur de <Book>
	 * @param pseudo
	 * @param password
	 * @param titre
	 * @param genre
	 * @param auteur
	 * @param nbPages
	 */
	public Book(String titre, String genre, String auteur, int nbPages) throws BadEntry{
		super(titre,genre);
		//tests sur l'auteur et le nb de pages
		if (auteur == null)
			throw new BadEntry("l'auteur n'est pas instancie");
		if(nbPages <= 0)
			throw new BadEntry("le nombre de pages est inferieur a 0"); 
		
		this.auteur = auteur;
		this.nbPages = nbPages;
		
	}
	
	/**
	 * méthode toString
	 * @return titre, genre, auteur, nombre de pages et tous les opinions du livre
	 */
	public String toString() {
		String message = "Le livre s'appelle : "+this.titre+". genre : "+this.genre+", auteur : "+this.auteur+", nombre de pages : "+this.nbPages+", note moyenne : "+this.calculMoyenne();
		for(Opinion opinion : mesOpinions) {
			message += "\n [" + opinion.toString() + "]";
		}
		
		return message;
	}
	
	
		/**
		 */
		public void main(){
		}

}

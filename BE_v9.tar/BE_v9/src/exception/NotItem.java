package exception;

public class NotItem extends Exception {

	public NotItem(String message) {
		super(message);
	}
}

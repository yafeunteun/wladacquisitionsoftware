package exception;

public class MemberAlreadyExists extends Exception {

}
